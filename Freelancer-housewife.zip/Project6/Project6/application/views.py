from django.shortcuts import render
from django.http import HttpResponse


# Create your views here.

def home(request):
    return render(request, 'index.html')

def aboutus(request):
    return render(request, 'about.html')

def problem_statement(request):
    return render(request, 'problem-statement.html')

def reg(request):
    return render(request, 'contact.html')